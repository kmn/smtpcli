ToDo
====

Features
--------

* Sending  email.

Improvement
-----------

* Using CC or BCC.
* Send to multiple destination mailaddress.
* Add "--no-confirm " option
* Add siguniture
* gpg

Known bug
---------

